#!/bin/sh
# centro_control.sh - Programa para realizar diversas tareas de administraci�n
# en un sistema Guadalinex Edici�n Bibliotecas: identificaci�n del centro, 
# copias de seguridad,  habilitaci�n de acceso externo, habilitaci�n de acceso a los clientes,...

# �Estamos en X?
if [ ! $DISPLAY ]; then
  : ${DIALOG=dialog}
else
  : ${DIALOG=Xdialog}
fi

NUM_CLIENTES=9

menu_principal()
{
  tempfile=`tempfile 2>/dev/null` || tempfile=/tmp/test$$
  trap "rm -f $tempfile" 0 1 2 5 15
  
  $DIALOG --clear --cancel-label "Salir" \
  	  --title "Centro de control" \
          --menu "Seleccione una de las siguientes opciones \n
para configurar y administrar diferentes aspectos del sistema\n\n"	0 0 8 \
          "Contrase�a" "Cambia la contrase�a del usuario 'biblio'" \
	  "Acceso" "Control de acceso remoto a los equipos" \
          "ID"  "Identificaci�n del centro" \
	  "Backup" "Copias de seguridad de los equipos" \
	  "Entrada" "Control de entrada externa" \
	  "Impresora" "Desatascador de impresora" \
	  "Estad�sticas" "Env�o de los ficheros de estad�sticas" 2> $tempfile 
  
  retval=$?
  
  choice=`cat $tempfile`
  
}

menu_contrase�a()
{
  old_fin=$fin
  fin=0

  while [ "$fin" != "1" ]
  do
# Men� de cambio de contrase�a para 'biblio'
  $DIALOG --ok-label "Aceptar" --password --password --2inputsbox "Introduzca a continuaci�n la nueva \n\
  contrase�a para el usuario 'biblio'" 16 32 "Contrase�a:" "" "Repita contrase�a:" "" 2> $tempfile

  retval=$?

  pass1=`cat $tempfile | awk -F"/" '{print $1}'`
  pass2=`cat $tempfile | awk -F"/" '{print $2}'`

  if [ "$retval" -ne "0" ]; then
    fin=1
  elif [ "x$pass1" == "x$pass2" ]; then
    echo "biblio:$pass1" > /tmp/pass.tmp
    chpasswd < /tmp/pass.tmp
    rm /tmp/pass.tmp
    $DIALOG --ok-label "Aceptar" --wrap --msgbox "La contrase�a ha sido cambiada satisfactoriamente" 10 30
    fin=1
  else
    $DIALOG --ok-label "Aceptar" --msgbox "Las contrase�as no coinciden" 8 30
  fi


  done

  fin=$old_fin
}


menu_id()
{
  CONF_FILE=/etc/biblio_id.conf
# Por si no existe, lo creamos
  touch $CONF_FILE

# Si existe alg�n problema creando el fichero, salimos
  if [ "$?" != "0" ]; then
    $DIALOG --msgbox "No se puede crear el fichero de configuraci�n..." 0 0
    return $?
  fi

# Cargamos el contenido del fichero de identificaci�n
  . $CONF_FILE

# Se distingue entre dialog/Xdialog
  if [ $DIALOG = "dialog" ]; then
    exec 3>&1
    value="`$DIALOG --ok-label "Aceptar" \
          --backtitle "Par�metros de identificaci�n del centro" \
          --form "Edite los par�metros de identificaci�n del centro:" \
12 70 0 \
        "Nombre de la localidad:" 	 1 1 "$NOMBRE_LOCALIDAD" 1 20 30 0 \
        "C�digo de la biblioteca:"	 2 1 "$ID_LOCALIDAD"  	 2 27  5 0 \
        "Nombre de la provincia:"	 3 1 "$NOMBRE_PROVINCIA" 3 25 10 0 \
        "Identificador de la provincia:" 4 1 "$ID_PROVINCIA" 	 4 32  5 0 \
    2>&1 1>&3`"
    returncode=$?
    exec 3>&-

    if [ $returncode = "0" ]; then # Se ha pulsado aceptar
      #show=`echo "$value" |sed -e 's/^/       /'`
      echo -e "$value" > "/tmp/gl_id.tmp"
      NOMBRE_LOCALIDAD=`sed -n '1p' /tmp/gl_id.tmp`
      ID_LOCALIDAD=`sed -n '2p' /tmp/gl_id.tmp`
      NOMBRE_PROVINCIA=`sed -n '3p' /tmp/gl_id.tmp`
      ID_PROVINCIA=`sed -n '4p' /tmp/gl_id.tmp`
      escribir="si"
    fi
  else # DIALOG = Xdialog
# 1a ventana: nombre de la localidad
    $DIALOG --title "Identificacion del centro" \
            --inputbox "Introduzca el nombre de la localidad del centro:" \
	     0 0 "$NOMBRE_LOCALIDAD" 2> /tmp/inputbox.tmp.$$
    
    retval=$?
    
    input=`cat /tmp/inputbox.tmp.$$`
    rm -f /tmp/inputbox.tmp.$$
    
    case $retval in
      0)
        NOMBRE_LOCALIDAD="$input";;
      *)
        return 1;;
    esac
# 2a ventana: identificaci�n de la localidad
    $DIALOG --title "Identificacion del centro" \
            --inputbox "Introduzca el c�digo de la biblioteca:" \
            0 0 "$ID_LOCALIDAD" 2> /tmp/inputbox.tmp.$$
    
    retval=$?
    
    input=`cat /tmp/inputbox.tmp.$$`
    rm -f /tmp/inputbox.tmp.$$
    
    case $retval in
      0)
        ID_LOCALIDAD="$input";;
      *)
        return 1;;
    esac
# 3a ventana: nombre de la provincia
    $DIALOG --title "Identificacion del centro" \
            --inputbox "Introduzca el nombre de la provincia:" \
            0 0 "$NOMBRE_PROVINCIA" 2> /tmp/inputbox.tmp.$$
    
    retval=$?
    
    input=`cat /tmp/inputbox.tmp.$$`
    rm -f /tmp/inputbox.tmp.$$
    
    case $retval in
      0)
        NOMBRE_PROVINCIA="$input";;
      *)
        return 1;;
    esac
# 4a ventana: identificador de la provincia
    $DIALOG --title "Identificacion del centro" \
            --inputbox "Introduzca el identificador de la provincia:" \
            0 0 "$ID_PROVINCIA" 2> /tmp/inputbox.tmp.$$
    
    retval=$?
    
    input=`cat /tmp/inputbox.tmp.$$`
    rm -f /tmp/inputbox.tmp.$$
    
    case $retval in
      0)
        ID_PROVINCIA="$input";;
      *)
        return 1;;
    esac

# Habilitamos la escritura en el fichero de configuraci�n
    escribir="si"
  fi

## Se cambia el mensaje de bienvenida del GDM y se env�a a los clientes
  cp /usr/share/gdm/themes/guadalinex/guadalinex.xml /usr/share/gdm/themes/guadalinex/guadalinex.xml.old
  gdmplantilla.py "$NOMBRE_LOCALIDAD" > /usr/share/gdm/themes/guadalinex/guadalinex.xml

(
  i=1
  while [ $i -le $NUM_CLIENTES ]
  do
    scp /usr/share/gdm/themes/guadalinex/guadalinex.xml 192.168.1.1$i:/usr/share/gdm/themes/guadalinex/guadalinex.xml&
    pid[$i]=`pidof scp /usr/share/gdm/themes/guadalinex/guadalinex.xml cliente-$i:/usr/share/gdm/themes/guadalinex/guadalinex.xml`
    let i=$i+1
    
    echo $i ; sleep .1
  done

# Esperamos a que se produzcan las copias remotas
  echo "15" ; sleep 1
  echo "30" ; sleep 1
  echo "45" ; sleep 1
  echo "60" ; sleep 1
  echo "75" ; sleep 1

  i=1
  while [ $i -le $NUM_CLIENTES ]
  do
    kill -9 ${pid[$i]}
    let i=$i+1
  done
  echo "100" ; sleep .1

) | $DIALOG --wrap --gauge "Propagando la informaci�n a los dem�s ordenadores..." 10 30 

  if [ "$escribir" = "si" ]; then  
    # Volcamos los datos en el fichero de configuraci�n
    echo "NOMBRE_LOCALIDAD=\"$NOMBRE_LOCALIDAD\"" > $CONF_FILE
    echo "ID_LOCALIDAD=\"$ID_LOCALIDAD\"" >> $CONF_FILE
    echo "NOMBRE_PROVINCIA=\"$NOMBRE_PROVINCIA\"" >> $CONF_FILE
    echo "ID_PROVINCIA=\"$ID_PROVINCIA\"" >> $CONF_FILE
  fi

# Mostramos un resumen con los valores introducidos
  $DIALOG --left --title "Identificacion del centro" \
          --msgbox " \
Nombre de la localidad:	        $NOMBRE_LOCALIDAD \n \
C�gido de la biblioteca:	$ID_LOCALIDAD \n \
Nombre de la provincia:         $NOMBRE_PROVINCIA \n \
Identificador de la provincia:  $ID_PROVINCIA" 0 0 10000
  return 0
}

menu_acceso()
{
# FIXME: Esto no funciona como dios manda: hay que hacer pruebas de detecci�n
# de clientes habilitados, deshabilitados,... y de habilitaci�n de acceso remoto

# Men� correspondiente a la gesti�n del acceso remoto a los clientes

# Averiguamos el estado de los clientes
# $cadena almacenar� lo que se va a mostrar en el Xdialog despu�s
# NUM_CLIENTES=5 # M�x 9 clientes
  cadena=""
  i=1
( while [ $i -le $NUM_CLIENTES ]
  do
    echo "XXX"
    echo "Buscando cliente-$i..."
    echo "XXX"
    IP_CLIENTE=192.168.1.1$i
    fping -t500 -c 1 -q $IP_CLIENTE > /dev/null 2> /dev/null
    if [ $? != "0" ] ; then # El cliente no est� presente
      cliente[$i]="No-presente"
    else # El cliente est� presente: avegiguamos su estado
      ssh $IP_CLIENTE ls > /dev/null 2> /dev/null &
      sleep 1
      pid="`pidof ssh $IP_CLIENTE `"
      kill -9 $pid
      ssh $IP_CLIENTE ls > /dev/null 2> /dev/null &
      sleep 1
      pid="`pidof ssh $IP_CLIENTE`"
# Si el PID es "", el cliente tiene habilitado el acceso remoto
      if [ "$pid" = "" ]; then
        cliente[$i]="Habilitado"
      else
        kill -9 $pid
        cliente[$i]="Deshabilitado"
      fi
    fi
    cadena="${cadena}cliente-$i ${cliente[$i]} "
# Escribimos la variable $cadena en un fichero para poder acceder desde fuera de 
# este bloque
    echo $cadena > /tmp/acceso.tmp

    let i=$i+1
  done ) | $DIALOG --title "Buscando clientes..." --infobox "" 0 0 0

# Se recupera el contenido de la variable $cadena del fichero
  cadena=`cat /tmp/acceso.tmp`

# Mostramos el estado de todos los clientes

$DIALOG --title "Estado de los clientes" \
        --ok-label "Seleccionar" --cancel-label "Salir" \
        --menu "A continuaci�n, se muestra el estado \n\
de todos los clientes del centro.\n\n \
Seleccione alguno para cambiar su estado: " 0 0 0 \
     $cadena         2> /tmp/menu.tmp.$$

  retval=$?
  
  choice=`cat /tmp/menu.tmp.$$`
  rm -f /tmp/menu.tmp.$$
  
  case $retval in
    0) # Se ha elegido un cliente
      end_part=${choice#"cliente-"}
      cliente=192.168.1.1$end_part
      xterm -e habilitar_acceso_remoto.sh $cliente
      menu_acceso
      ;;
    *)
      return 1
  esac 
  
    return 0
}



menu_backup()
{
# Men� correspondiente a la gesti�n de las copias de seguridad en servidor y clientes
  $DIALOG --title "Copias de seguridad" \
          --menu "Seleccione a continuaci�n si desea hacer una copia de \n\
seguridad de los equipos de usuario o del bibliotecario:" 0 0 4 \
        "usuario" "Backup de los equipos de usuario" \
          "biblio"  "Backup del equipo de bibliotecario" 2> /tmp/backup.tmp.$$

  retval=$?

  choice=`cat /tmp/backup.tmp.$$`
  rm -f /tmp/backup.tmp.$$

  case $retval in
    0) # Se ha seleccionado alguna de las dos entradas
      if [ "$choice" = "usuario" ]; then
        hacer_backup_clientes.sh
      else
        duplicar_sistema.sh
	$DIALOG --title "Copias de seguridad" --msgbox "La copia de seguridad \
	del ordenador de bibliotecario ha concluido" 0 0 
      fi
      menu_backup
      ;;
    *)
      return 1
      ;;
  esac
    return 0
  return 0
}
menu_impresora()
{
# Desatascador de impresoras
  (cupsenable impresora-laser
  sudo apt-get clean
  sudo apt-get update 
  sudo apt-get update 
  sleep 10s
  cupsenable impresora-laser) | zenity --progress --pulsate --auto-close --title="Desatascador de impresoras" --text="Reconfigurando la impresora... En unos minutos comenzará a imprimir." 
}

menu_estadisticas()
{
# Men� correspondiente al env�o de los ficheros de logs de entradas/salidas 
  
  . /etc/email_estadisticas.conf

  $DIALOG --title "Envio de estadisticas" \
          --ok-label "Seleccionar" --cancel-label "Salir" \
          --menu "Seleccione si desea realizar un nuevo env�o de los ficheros \n\
de estad�sticas o cambiar la direcci�n de env�o:" 0 0 4 \
        "enviar" "Env�a ficheros de estad�sticas" \
        "cambiar"  "$TO_ADDR" 2> /tmp/envio.tmp.$$ 

  retval=$?

  choice=`cat /tmp/envio.tmp.$$`
  rm -f /tmp/envio.tmp.$$

  case $retval in
    0) # Se ha seleccionado alguna de las dos entradas
      if [ "$choice" = "enviar" ]; then
        /etc/cron.monthly/logs # Realiza un nuevo env�o
        $DIALOG  --title "Envio de estadisticas" \
                 --msgbox "Se han enviado las estad�sticas correctamente \n
a la direcci�n:\n\n
$TO_ADDR" 0 0 10000
	
      else
        $DIALOG --title "Cambio de direccion de envio" \
        --inputbox "Introduzca la direcci�n de correo donde \n\
desea que se env�en las estad�sticas a partir de ahora:" \
             0 0 $TO_ADDR 2> /tmp/envio.tmp.$$ 

        retval=$?
    
        input=`cat /tmp/envio.tmp.$$`
        rm -f /tmp/envio.tmp.$$
    
        case $retval in
          0)
            TO_ADDR="$input"
    	    echo "TO_ADDR=\"$TO_ADDR\"" > /etc/email_estadisticas.conf
	    $DIALOG --title "Cambio de direccion de envio" \
	    --msgbox "La direcci�n de env�o de estad�sticas se ha cambiado a:\n $TO_ADDR" 0 0 0 
            menu_estadisticas
     	    ;;
          *)
            return 1;;
        esac
 
      fi
      ;;
    *)
      return 1
      ;;
  esac

  return 0
}

menu_entrada()
{
# Men� correspondiente a la gesti�n del acceso externo al servidor via SSH
  habilitar_acceso_externo.sh
  return 0
}


# Comienza la ejecuci�n del programa

fin=0

while [ "$fin" != "1" ]
do
  menu_principal

  if [ "$retval" = "1" -o "$retval" = "255" ]; then
    fin=1
  else
    case "$choice" in
      "Contrase�a")
        menu_contrase�a
	;;
      "ID")
        menu_id
	;;
      "Entrada")
        menu_entrada
	;;
      "Acceso")
        menu_acceso
	;;
      "Backup")
        menu_backup
	;;
      "Impresora")
        menu_impresora
	;;
      "Estad�sticas")
        menu_estadisticas
	;;
      *)
        fin=1
	;;	
    esac	
  fi
  
done
